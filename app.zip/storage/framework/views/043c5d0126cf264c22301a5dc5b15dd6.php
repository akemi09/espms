<div>
    <div class="table-response mt-3 overflow-auto">
        <table class="table mb-3">
            <thead>
                <tr>
                    <th>MFO/PAP</th>
                    <th>Target + Measure</th>
                    <th>Actual Accomplishments</th>
                    <th>Q1</th>
                    <th>E2</th>
                    <th>T3</th>
                    <th>A4</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <!-- __BLOCK__ --><?php $__empty_1 = true; $__currentLoopData = $pcrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pcr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($pcr->mfo_pap->title); ?></td>
                        <td><?php echo e($pcr->targets); ?></td>
                        <td><?php echo e($pcr->actual_accomplishments); ?></td>
                        <td><?php echo e($pcr->q1); ?></td>
                        <td><?php echo e($pcr->e2); ?></td>
                        <td><?php echo e($pcr->t3); ?></td>
                        <td><?php echo e($pcr->a4); ?></td>
                        <td>
                            <button wire:click="rate(<?php echo e($pcr->id); ?>)" class="dropdown-item"
                                data-bs-toggle="modal" data-bs-target="#rateIpcrModal"><i
                                    class="bx bx-edit-alt me-1"></i> Rate</button>
                        </td>
                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8">No records</td>
                    </tr>
                <?php endif; ?> <!-- __ENDBLOCK__ -->

                <tr>
                    <td>STRATEGIC FUNCTION (45%)</td>
                    <td colspan="7" class="text-end"><?php echo e(number_format($strategic, 2)); ?></td>
                </tr>
                <tr>
                    <td>CORE FUNCTIONS (45%)</td>
                    <td colspan="7" class="text-end"><?php echo e(number_format($core, 2)); ?></td>
                </tr>
                <tr>
                    <td>SUPPORT FUNCTIONS (10%)</td>
                    <td colspan="7" class="text-end"><?php echo e(number_format($support, 2)); ?></td>
                </tr>
                <tr>
                    <td>TOTAL OVERALL RATING</td>
                    <td colspan="7" class="text-end"><?php echo e(number_format($strategic + $core + $support, 2)); ?></td>
                </tr>
            </tbody>
        </table>

    </div>

        <!-- Add Office Modal -->
        <div class="modal fade" data-bs-backdrop="static" id="rateIpcrModal" tabindex="-1" style="display: none;"
        aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form>
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel1">Rate IPCR</h5>
                        <button type="button" wire:click="cancel" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <?php echo $__env->make('layouts.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="row">
                            <div class="mb-3">
                                <label for="actual_accomplishment" class="form-label">Actual Accomplishments</label>
                                <input wire:model="actual_accomplishment" type="text" id="actual_accomplishment"
                                    class="form-control <?php $__errorArgs = ['actual_accomplishment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="">
                                <!-- __BLOCK__ --><?php $__errorArgs = ['actual_accomplishment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger" role="alert">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!-- __ENDBLOCK__ -->
                            </div>

                            <div class="mb-3">
                                <label for="q1" class="form-label">Q1</label>
                                <input wire:model="q1" type="number" id="q1"
                                    class="form-control <?php $__errorArgs = ['q1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="5">
                                <!-- __BLOCK__ --><?php $__errorArgs = ['q1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger" role="alert">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!-- __ENDBLOCK__ -->
                            </div>

                            <div class="mb-3">
                                <label for="e2" class="form-label">E2</label>
                                <input wire:model="e2" type="number" id="e2"
                                    class="form-control <?php $__errorArgs = ['e2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="5">
                                <!-- __BLOCK__ --><?php $__errorArgs = ['e2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger" role="alert">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!-- __ENDBLOCK__ -->
                            </div>

                            <div class="mb-3">
                                <label for="t3" class="form-label">T3</label>
                                <input wire:model="t3" type="number" id="t3"
                                    class="form-control <?php $__errorArgs = ['t3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="5">
                                <!-- __BLOCK__ --><?php $__errorArgs = ['t3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger" role="alert">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!-- __ENDBLOCK__ -->
                            </div>

                            <div class="mb-3">
                                <label for="a4" class="form-label">A4</label>
                                <input wire:model="a4" type="number" id="a4"
                                    class="form-control"
                                     readonly disabled>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" wire:click="cancel" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" wire:click="save" wire:loading.attr="disabled"
                            class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Julz\Desktop\Personal\laravel-docker\spms\resources\views/livewire/ipcr.blade.php ENDPATH**/ ?>