<div>
    <div class="row">
        <div class="col-md-6">
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addNewMFOPAPModal"><i
                    class="bx bx-plus"></i> Add New MFO/PAP</button>
        </div>
        <div class="col-md-6">
            <input type="text" class="form-control" placeholder="Search" wire:model.live.debounce.150ms="query"
                wire:keydown='search'>
        </div>
    </div>
    <div class="table-responsive mt-3">
        <table class="table mb-3">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Target Function</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <!-- __BLOCK__ --><?php $__empty_1 = true; $__currentLoopData = $mfo_paps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mfo_pap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($mfo_pap->title); ?></td>
                        <td><?php echo e($mfo_pap->target_function->name); ?></td>
                        <td>
                            <div class="dropdown">
                                <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                    data-bs-toggle="dropdown" aria-expanded="false"><i
                                        class="bx bx-dots-vertical-rounded"></i></button>
                                <div class="dropdown-menu" style="">
                                    <button wire:click="edit(<?php echo e($mfo_pap->id); ?>)" class="dropdown-item"
                                        data-bs-toggle="modal" data-bs-target="#editMFOPAPModal"><i
                                            class="bx bx-edit-alt me-1"></i> Edit</button>
                                    <button wire:click="destroy(<?php echo e($mfo_pap->id); ?>)"
                                        onclick="return confirm('You are about to delete MFO/PAP. Continue?') || event.stopImmediatePropagation()"
                                        type="submit" class="btn btn-link dropdown-item"><i
                                            class="bx bx-trash me-1"></i> Delete</button>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4">No records</td>
                    </tr>
                <?php endif; ?> <!-- __ENDBLOCK__ -->
            </tbody>
            <tfoot>
                <tr>
                    <th>Title</th>
                    <th>Target Function</th>
                    <th>Action</th>
                </tr>
            </tfoot>
        </table>

        <?php echo e($mfo_paps->links()); ?>

    </div>

    <!-- Add Office Modal -->
    <div class="modal fade" data-bs-backdrop="static" id="addNewMFOPAPModal" tabindex="-1" style="display: none;"
        aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form>
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel1">Add New MFO/PAP</h5>
                        <button type="button" wire:click="cancel" class="btn-close" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="mb-3">
                                <label for="title" class="form-label">Title</label>
                                <textarea wire:model="title" type="text" id="title" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    rows="2" placeholder="e.g Early Procurement and Utilization of Budget"></textarea>
                                <!-- __BLOCK__ --><?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger" role="alert">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!-- __ENDBLOCK__ -->
                            </div>

                            <div class="mb-3">
                                <label for="office" class="form-label">Available in</label>
                                <select id="office" class="form-control" wire:model="office" multiple="multiple"
                                    size="10">
                                    <!-- __BLOCK__ --><?php $__currentLoopData = $offices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $office): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($office->id); ?>"><?php echo e($office->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- __ENDBLOCK__ -->
                                </select>
                                Press <code>CTRL</code> to select multiple
                                <!-- __BLOCK__ --><?php $__errorArgs = ['office'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger" role="alert">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!-- __ENDBLOCK__ -->
                            </div>

                            <div class="mb-3">
                                <label for="target_function" class="form-label">Select Target Function</label>
                                <select class="form-control" wire:model="target_function" id="target_function">
                                    <option value="">Select Option</option>
                                    <!-- __BLOCK__ --><?php $__currentLoopData = $target_functions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($tf->id); ?>"><?php echo e($tf->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- __ENDBLOCK__ -->
                                </select>
                                <!-- __BLOCK__ --><?php $__errorArgs = ['target_function'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger" role="alert">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!-- __ENDBLOCK__ -->
                            </div>

                            

                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" wire:click="cancel" class="btn btn-outline-secondary"
                            data-bs-dismiss="modal">Close</button>
                        <button type="button" wire:click="store" wire:loading.attr="disabled"
                            class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Office Modal -->
    <div class="modal fade" data-bs-backdrop="static" id="editMFOPAPModal" tabindex="-1" style="display: none;"
        aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form>
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel1">Edit MFO/PAP</h5>
                        <button type="button" wire:click="cancel" class="btn-close" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="mb-3">
                                <label for="title" class="form-label">Title</label>
                                <textarea wire:model="title" type="text" id="title" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    rows="2" placeholder="e.g Early Procurement and Utilization of Budget"><?php echo e($title); ?></textarea>
                                <!-- __BLOCK__ --><?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger" role="alert">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!-- __ENDBLOCK__ -->
                            </div>

                            <div class="mb-3">
                                <label for="office" class="form-label">Available in</label>
                                <select class="form-control" wire:model="office" multiple="multiple" size="10">
                                    <!-- __BLOCK__ --><?php $__currentLoopData = $offices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $office): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($office->id); ?>"><?php echo e($office->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- __ENDBLOCK__ -->
                                </select>
                                Press <code>CTRL</code> to select multiple
                                <!-- __BLOCK__ --><?php $__errorArgs = ['office'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger" role="alert">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!-- __ENDBLOCK__ -->
                            </div>

                            <div class="mb-3">
                                <label for="target_function" class="form-label">Select Target Function</label>
                                <select class="form-control" wire:model="target_function">
                                    <option value="">Select Option</option>
                                    <!-- __BLOCK__ --><?php $__currentLoopData = $target_functions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($tf->id); ?>"><?php echo e($tf->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- __ENDBLOCK__ -->
                                </select>
                                <!-- __BLOCK__ --><?php $__errorArgs = ['target_function'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger" role="alert">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!-- __ENDBLOCK__ -->
                            </div>

                            

                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" wire:click="cancel" class="btn btn-outline-secondary"
                            data-bs-dismiss="modal">Close</button>
                        <button type="button" wire:click="update" wire:loading.attr="disabled"
                            class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Julz\Desktop\Personal\laravel-docker\spms\resources\views/livewire/mfo-pap.blade.php ENDPATH**/ ?>