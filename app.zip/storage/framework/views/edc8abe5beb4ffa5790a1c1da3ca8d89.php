<div>
    <div class="row">
        <div class="table-response text-nowrap mt-3">
            <table class="table mb-3">
                <thead>
                    <tr>
                        <th rowspan="2">Roles</th>
                        <th colspan="4" class="text-center">Set Permissions</th>
                    </tr>
                    <tr>
                        <th>Create</th>
                        <th>Read</th>
                        <th>Update</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- __BLOCK__ --><?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(Str::upper($role->name)); ?></td>
                            <td>
                                <input wire:model="permissions"
                                class="form-check-input"
                                type="checkbox" value="<?php echo e($role->name); ?>.create" id="create<?php echo e($key); ?>">
                            </td>
                            <td>
                                <input wire:model="permissions"
                                class="form-check-input"
                                type="checkbox" value="<?php echo e($role->name); ?>.read" id="read<?php echo e($key); ?>">
                            </td>
                            <td>
                                <input wire:model="permissions"
                                class="form-check-input"
                                type="checkbox" value="<?php echo e($role->name); ?>.update" id="update<?php echo e($key); ?>">
                            </td>
                            <td>
                                <input wire:model="permissions"
                                class="form-check-input"
                                type="checkbox" value="<?php echo e($role->name); ?>.delete" id="delete<?php echo e($key); ?>">
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- __ENDBLOCK__ -->
                </tbody>
            </table>
            
            <button type="button" wire:click="save" wire:loading.attr="disabled"
                            class="btn btn-primary">Save</button>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Julz\Desktop\Personal\laravel-docker\spms\resources\views/livewire/roles-and-permission.blade.php ENDPATH**/ ?>