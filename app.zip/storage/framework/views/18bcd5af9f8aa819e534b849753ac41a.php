<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Report</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="col-md-12 text-center">
        <p class="fw-bold">
            INDIVIDUAL PERFORMANCE COMMITMENT AND REVIEW (IPCR)
        </p>
    </div>

    <div class="col-md-12">
        <p>
            I, <u><?php echo e(Str::upper($user->name)); ?></u>, faculty of the College of <?php echo e(Str::upper($user->office->name)); ?>,
            commits to deliver and agree to be rated on the attainment of the following targets in accordance with the
            indicated measures for the period January to June 2023.</u>
        </p>
    </div>

    <div class="col-md-12">
        <div class="table-responsive">
            <table class="table table-bordered" style="border: 1px;">
                <thead>
                    <th>Noted by:</th>
                    <th>Verified by:</th>
                    <th>Approved by:</th>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <p class="text-center mt-3">
                                CHALLIZ D. OMOROG, DIT
                            </p>
                            <p class="lh-1 text-center">Dean</p>
                        </td>
                        <td>
                            <p class="text-center mt-3">
                                ESTELITO R. CLEMENTE, PhD
                            </p>
                            <p class="lh-1 text-center">VP for Academic Affairs</p>
                        </td>
                        <td>
                            <p class="text-center mt-3">
                                DULCE F. ATIAN, PhD
                            </p>
                            <p class="lh-1 text-center">Officer-in-Charge</p>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <div class="col-md-12 mt-4">
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead class="text-center">
                    <tr>
                        <th rowspan="2">MFO/PAP</th>
                        <th rowspan="2">SUCCESS INDICATORS
                            (TARGETS + MEASURES)</th>
                        <th rowspan="2">Actual Accomplishments</th>
                        <th colspan="4">Rating</th>
                        <th rowspan='2'>Remarks</th>
                    </tr>
                    <tr>
                        <th>Q1</th>
                        <th>E2</th>
                        <th>T3</th>
                        <th>A4</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $ipcr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $targetFunction => $mfoPaps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td colspan="8" class="text-dark bg-warning"><?php echo e(Str::upper($targetFunction)); ?></td>
                        </tr>
                        <?php $__currentLoopData = $mfoPaps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mfoPap => $targets): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td rowspan="<?php echo e(count($targets) + 1); ?>"><?php echo e($mfoPap); ?></td>
                            </tr>
                            <?php $__currentLoopData = $targets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $target): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($target->targets); ?></td>
                                    <td><?php echo e($target->actual_accomplishments); ?></td>
                                    <td><?php echo e($target->q1); ?></td>
                                    <td><?php echo e($target->e2); ?></td>
                                    <td><?php echo e($target->t3); ?></td>
                                    <td><?php echo e($target->a4); ?></td>
                                    <td><?php echo e($target->remarks); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8">No results</td>
                        </tr>
                    <?php endif; ?>
                    <tr>
                        <td colspan="7">STRATEGIC FUNCTION (45%)</td>
                        <td colspan="1"><?php echo e(number_format($strategic, 2)); ?></td>
                    </tr>
                    <tr>
                        <td colspan="7">COR FUNCTION (45%)</td>
                        <td colspan="1"><?php echo e(number_format($core, 2)); ?></td>
                    </tr>
                    <tr>
                        <td colspan="7">SUPPORT FUNCTION (10%)</td>
                        <td colspan="1"><?php echo e(number_format($support, 2)); ?></td>
                    </tr>
                    <tr>
                        <td colspan="7">TOTAL OVERALL RATING</td>
                        <td colspan="1"><?php echo e(number_format($strategic + $core + $support, 2)); ?></td>
                    </tr>

                    <tr>
                        <td colspan="8">Comments and Recommendation for Development Purposes</td>
                    </tr>


                    <tr class="text-center">
                        <td>Discuss with:</td>
                        <td>Assessed by:</td>
                        <td>Noted by:</td>
                        <td colspan="4">Approved by:</td>
                        <td>Date:</td>
                    </tr>

                    <tr>
                        <td rowspan="2">
                            <?php if($signed != ""): ?>
                            <img src="<?php echo e(public_path('storage/' . $signed)); ?>" alt="signature" width="150px" height="100px">
                            <?php endif; ?>
                        </td>
                        <td>I certify that I discussed my assessment of the performance with the employee</td>
                        <td rowspan="2">&nbsp;</td>
                        <td colspan="4" rowspan="2">&nbsp;</td>
                        <td rowspan="2">&nbsp;</td>
                    </tr>

                    <tr>
                        <td>&nbsp;</td>
                    </tr>

                    <tr class="text-center">
                        <td><?php echo e(auth()->user()->name); ?></td>
                        <td>CHALLIZ DELIMA-OMOROG, DIT</td>
                        <td>ESTELITO R. CLEMENTE, PhD</td>
                        <td colspan="4">DULCE F. ATIAN, PhD</td>
                        <td>&nbsp;</td>
                    </tr>
                    <tr class="text-center">
                        <td><?php echo e(auth()->user()->designation); ?></td>
                        <td>Dean</td>
                        <td>VPAA</td>
                        <td colspan="4">Officer-in-charge</td>
                        <td>&nbsp;</td>
                    </tr>

                </tbody>
            </table>
        </div>
    </div>
</body>
</html><?php /**PATH C:\Users\Julz\Desktop\Personal\laravel-docker\spms\resources\views/pdf.blade.php ENDPATH**/ ?>