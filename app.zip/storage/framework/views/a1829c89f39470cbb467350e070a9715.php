<div>
    <div class="row">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-users')): ?>
            <div class="col-lg-3 col-md-3 col-3 mb-4">
                <div class="card">
                    <div class="card-body">
                        <div class="card-title d-flex align-items-start justify-content-between">
                            <div class="avatar flex-shrink-0">
                                <span class="avatar-initial rounded bg-label-success"><i class="bx bx-user"></i></span>
                            </div>
                            <div class="dropdown">
                                <button class="btn p-0" type="button" id="cardOpt6" data-bs-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                    <i class="bx bx-dots-vertical-rounded"></i>
                                </button>
                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="cardOpt6" style="">
                                    <a class="dropdown-item" href="<?php echo e(route('users.index')); ?>">View More</a>
                                </div>
                            </div>
                        </div>
                        <span>Users</span>
                        <h3 class="card-title text-nowrap mb-1"><?php echo e(\App\Models\User::count()); ?></h3>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <div class="col-md-12">
            <div id='calendar'></div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                var calendarEl = document.getElementById('calendar');
                var calendar = new FullCalendar.Calendar(calendarEl, {
                    nextDayThreshold:'00:00',
                    initialView: 'dayGridMonth',
                    events: <?php echo $data; ?>

                });

                calendar.render();
            });
        </script>
    <?php $__env->stopPush(); ?>
</div>
<?php /**PATH C:\Users\Julz\Desktop\Personal\laravel-docker\spms\resources\views/livewire/dashboard.blade.php ENDPATH**/ ?>