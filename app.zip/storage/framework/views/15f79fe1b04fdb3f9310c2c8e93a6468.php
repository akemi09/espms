<div>
    <div class="row">
        <div class="col-md-12">
            <div class="accordion mt-3" id="accordionExample">
                <!-- __BLOCK__ --><?php $__currentLoopData = $target_functions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $target_function): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card accordion-item">
                        <h2 class="accordion-header" id="headingOne">
                            <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse"
                                data-bs-target="#accordion<?php echo e($key); ?>" aria-expanded="false"
                                aria-controls="accordion<?php echo e($key); ?>">
                                <?php echo e($target_function->name); ?>

                            </button>
                        </h2>

                        <div id="accordion<?php echo e($key); ?>" class="accordion-collapse collapse show"
                            data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                <!-- __BLOCK__ --><?php $__currentLoopData = $mfo_paps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $mfo_pap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <!-- __BLOCK__ --><?php if($key == $target_function->id): ?>
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th>MFO/PAP</th>
                                                    <th>Targets + Measures</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <!-- __BLOCK__ --><?php $__currentLoopData = $mfo_pap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td width="80%"><?php echo e($mp['title']); ?></td>
                                                        <td>
                                                            <button wire:click="edit(<?php echo e($mp['id']); ?>)"
                                                                class="btn btn-primary" data-bs-toggle="modal"
                                                                data-bs-target="#editTargetModal">Action</button>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- __ENDBLOCK__ -->
                                            </tbody>
                                        </table>
                                    <?php endif; ?> <!-- __ENDBLOCK__ -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- __ENDBLOCK__ -->
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- __ENDBLOCK__ -->

                
            </div>
        </div>
    </div>

    <!-- Edit Target Modal -->
    <div class="modal fade" data-bs-backdrop="static" id="editTargetModal" tabindex="-1" style="display: none;"
        aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <form>
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel1">Add/Edit Target</h5>
                        <button type="button" wire:click="cancel" class="btn-close" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <?php echo $__env->make('layouts.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="row">
                            <div class="col mb-3">
                                <?php if(count($targets) > 0): ?>
                                    <!-- __BLOCK__ --><?php $__currentLoopData = $targets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $target): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <input type="hidden" wire:model="targets.<?php echo e($key); ?>.id">
                                        <div class="row">
                                            <label for="targets.<?php echo e($key); ?>.parent">Parent</label>
                                            <select class="form-control" wire:model="targets.<?php echo e($key); ?>.parent_id"
                                                id="targets.<?php echo e($key); ?>.parent">
                                                <option value="">None</option>
                                                <!-- __BLOCK__ --><?php $__currentLoopData = $my_targets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($mt->id); ?>"><?php echo e($mt->targets); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- __ENDBLOCK__ -->
                                            </select>
                                        </div>
                                        <div class="row mt-1">
                                            <input wire:model="targets.<?php echo e($key); ?>.title" type="text"
                                                id="targets.<?php echo e($key); ?>.title"
                                                class="mb-2 form-control <?php $__errorArgs = ['targets.' . $key . '.title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        </div>
                                        <button type="buttn" wire:click.prevent="destroy(<?php echo e($key); ?>)"
                                            class="mb-2 btn btn-danger btn-sm">remove</button>
                                        <!-- __BLOCK__ --><?php $__errorArgs = ['targets.' . $key . '.title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger" role="alert">
                                                <?php echo e($message); ?>

                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!-- __ENDBLOCK__ -->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!-- __ENDBLOCK__ -->
                                <?php endif; ?> <!-- __ENDBLOCK__ -->
                                <button type="button" class="btn btn-primary mt-2 float-end"
                                    wire:click="addTarget">add</button>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" wire:click="cancel" class="btn btn-outline-secondary"
                            data-bs-dismiss="modal">Close</button>
                        <button type="button" wire:click="update" wire:loading.attr="disabled"
                            class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Julz\Desktop\Personal\laravel-docker\spms\resources\views/livewire/my-targets.blade.php ENDPATH**/ ?>