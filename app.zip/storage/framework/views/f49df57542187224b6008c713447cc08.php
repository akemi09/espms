<div>
    <div class="table-response text-nowrap mt-3">
        <table class="table mb-3">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Office</th>
                    <th>Designation</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <!-- __BLOCK__ --><?php $__empty_1 = true; $__currentLoopData = $pcr_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pcr_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($pcr_user->user->name); ?></td>
                        <td><?php echo e($pcr_user->user->office->name); ?></td>
                        <td><?php echo e($pcr_user->user->designation); ?></td>
                        <td>
                            <a class="btn btn-primary" href="<?php echo e(route('target.approvals.show', $pcr_user->user_id)); ?>">View</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4">No records</td>
                    </tr>
                <?php endif; ?> <!-- __ENDBLOCK__ -->
            </tbody>
            <tfoot>
                <tr>
                    <th>Name</th>
                    <th>Office</th>
                    <th>Designation</th>
                    <th>Action</th>
                </tr>
            </tfoot>
        </table>

        <?php echo e($pcr_users->links()); ?>

    </div>
</div>
<?php /**PATH C:\Users\Julz\Desktop\Personal\laravel-docker\spms\resources\views/livewire/target-approval.blade.php ENDPATH**/ ?>