<div>
    <div class="table-response text-nowrap mt-3">
        <table class="table mb-3">
            <thead>
                <tr>
                    <th>Details</th>
                </tr>
            </thead>
            <tbody>
                <!-- __BLOCK__ --><?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($log->causer->name); ?> <?php echo e($log->description); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4">No records</td>
                    </tr>
                <?php endif; ?> <!-- __ENDBLOCK__ -->
            </tbody>
            <tfoot>
                <tr>
                    <th>Detail</th>
                </tr>
            </tfoot>
        </table>

        <?php echo e($logs->links()); ?>

    </div>
</div>
<?php /**PATH C:\Users\Julz\Desktop\Personal\laravel-docker\spms\resources\views/livewire/log.blade.php ENDPATH**/ ?>